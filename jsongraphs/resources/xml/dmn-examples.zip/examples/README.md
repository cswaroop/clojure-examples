These are non-normative examples to illustrate the use of the DMN XML Schema.
